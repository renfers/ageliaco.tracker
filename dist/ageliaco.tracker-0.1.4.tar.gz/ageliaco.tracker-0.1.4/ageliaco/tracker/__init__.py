  # -*- extra stuff goes here -*- 
from zope.i18nmessageid import MessageFactory

_ = MessageFactory('ageliaco.tracker')

